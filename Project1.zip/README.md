# SwiftShop — Modern E-Commerce Storefront

A fast, highly scalable, and responsive e-commerce web application built using **React**, **Vite**, **Tailwind CSS (v4)**, and **React Router (v6)**. This platform utilizes centralized state management via React Context to build an optimized, interactive user experience.

---

## 🚀 Core Features

- **Persistent Global Shopping Cart:** Add items, dynamically scale quantities up/down, or remove items from any point in the store. Persists items across hard page refreshes using `localStorage`.
- **Centralized Structural Shell:** Implements a single global Layout architecture (`RootLayout`) utilizing React Router `<Outlet />` for layout caching and smooth navigation transitions.
- **Dynamic Context Navigation:** Utilizes `<NavLink>` wrappers to dynamically update active state navigation highlighting on the navigation header.
- **Modern UI Styling Tokens:** Built with a fully custom fluid styling configuration powered natively by Tailwind CSS v4 and clean vector-based layout assets using `lucide-react`.
- **Conversion-Focused Layouts:** Includes dedicated page templates for landing showcases, fully interactable product grids, responsive contact query submissions, and brand core definitions.

---

## 🛠️ The Tech Stack

- **Frontend Framework:** React.js (via Vite scaffolding template)
- **Styling Architecture:** Tailwind CSS v4
- **Routing Engine:** React Router DOM v6
- **Interface Icons:** Lucide React
- **State Architecture:** React Context API (with synchronized local storage integration)

---

## 📁 Repository Directory Structure

```text
src/
├── components/       # Reusable global layout elements (Navbar, Footer)
├── context/          # Centralized data systems (CartContext containing arithmetic)
├── layouts/          # Common structural frames (RootLayout featuring <Outlet />)
├── pages/            # Core views (Home, Products, About, Contact, CartPage)
├── App.jsx           # Application Router Configuration mapping
└── main.jsx          # Root initialization point injecting the CartProvider global shell
